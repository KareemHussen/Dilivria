<?php

return [
    "address added successfully" => "address added successfully",
    "couldn't add your address" => "couldn't add your address, please try again",
    "address update" => "address updated successfully",
    "undefined address" => "undefined address, please enter a used address",
    "deleted" => "address deleted successfully",
    "no results" => "you favorites menu is empty, try adding some addesses",
    "wallet"=> "Wallet"
];