<?php

return [
    "settings" => "Settings",
    "contact_phone" => "Vodafone Cash Phone",
    "company_address" => "Instapay Address",
    "phone_helper" => "Vodafone Cash Phone Number",
    "address_helper" => "Instapay address starting with @"
];
