<?php

return [
    "info updated" => "info updated successfully",
    "error info update" => "server error occurred",
    "delivery docs sent" => "you docs has been sent, please wait for admin review"

];