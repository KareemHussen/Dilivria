<?php

return [
    "address added successfully" => "تمت إضافة العنوان بنجاح",
    "couldn't add your address" => "لم يتمكن من إضافة العنوان، يرجى المحاولة مرة أخرى",
    "address update" => "تم تحديث العنوان بنجاح",
    "undefined address" => "عنوان غير معروف، يرجى إدخال عنوان مستخدم",
    "deleted" => "تم حذف العنوان بنجاح",
    "no results" => "قائمة المفضلات الخاصة بك فارغة، حاول إضافة بعض العناوين",
    "wallet" => "محفظة"
];
