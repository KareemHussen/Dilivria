<?php

return [
    "settings" => "الإعدادات",
    "contact_phone" => "رقم فودافون كاش",
    "company_address" => "عنوان انستاباي",
    "phone_helper" => "رقم فودافون كاش للدفع",
    "address_helper" => "عنوان انستاباي يبدأ بعلامة @"
];
