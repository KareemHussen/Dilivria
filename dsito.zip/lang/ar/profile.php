<?php

return [
    "info updated" => "تم تحديث البيانات بنجاح",
    "error info update" => "حدث خطأ في الخادم",
    "delivery docs sent" => "تم ارسال مستنداتك، من فضلك انتظر مراجعة المشرف"
];