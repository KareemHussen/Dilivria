<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\PlaceOrder;
use App\Traits\HandleResponseTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    use HandleResponseTrait;

    public function getAll(Request $request)
    {
        $validated = $request->validate([
            'per_page'       => 'nullable|integer|min:1|max:100',
            'status'         => 'nullable|in:active,completed,cancelled,pending',
            'payment_method' => 'nullable|string|in:cash,card,wallet',
            'from_date'      => 'nullable|date',
            'to_date'        => 'nullable|date|after_or_equal:from_date',
            'sort_by'        => 'nullable|in:created_at,price,id',
            'sort_order'     => 'nullable|in:asc,desc',
        ]);

        $user = $request->user();
        $perPage = $validated['per_page'] ?? 15;

        $query = PlaceOrder::query()
            ->where('customer_id', $user->id)
            ->with([
                'order',
                'order.delivery:id,full_name,phone,delivery_rate,lng,lat'
            ]);

        // ✅ Status filter
        if (!empty($validated['status'])) {
            $query->where(function ($q) use ($validated) {
                match ($validated['status']) {

                    'active' => $q->whereHas('order', fn ($order) =>
                        $order->whereNotIn('status', [
                            'completed',
                            'cancelled_user',
                            'cancelled_delivery'
                        ])
                    ),

                    'completed' => $q->whereHas('order', fn ($order) =>
                        $order->where('status', 'completed')
                    ),

                    'cancelled' => $q->where(function ($subQ) {
                        $subQ->where('status', 'cancelled')
                            ->orWhereHas('order', fn ($order) =>
                                $order->whereIn('status', [
                                    'cancelled_user',
                                    'cancelled_delivery'
                                ])
                            );
                    }),

                    'pending' => $q->where('status', 'pending')
                        ->doesntHave('order'),

                    default => null
                };
            });
        }

        // ✅ Simple filters
        $query
            ->when($validated['payment_method'] ?? null,
                fn ($q, $method) => $q->where('payment_method', $method)
            )
            ->when($validated['from_date'] ?? null,
                fn ($q, $date) => $q->whereDate('created_at', '>=', $date)
            )
            ->when($validated['to_date'] ?? null,
                fn ($q, $date) => $q->whereDate('created_at', '<=', $date)
            );

        // ✅ Sorting (safe)
        $sortBy    = $validated['sort_by']   ?? 'created_at';
        $sortOrder = $validated['sort_order'] ?? 'desc';

        $orders = $query
            ->orderBy($sortBy, $sortOrder)
            ->paginate($perPage);

        return $this->handleResponse(
            true,
            '',
            [],
            [
                'orders' => $orders->items(),
                'pagination' => [
                    'current_page' => $orders->currentPage(),
                    'last_page'    => $orders->lastPage(),
                    'per_page'     => $orders->perPage(),
                    'total'        => $orders->total(),
                ],
            ],
            []
        );
    }

    public function getLast(Request $request){
        $user = $request->user();
        $lastOrder = PlaceOrder::where('customer_id', $user->id)
        ->whereHas('order', function ($query){
            $query->where('status', 'completed');

        })->with(['order', 'order.delivery' => function ($q){
            $q->select( "id","full_name", "phone", "delivery_rate","lng", "lat",);
        }])->latest()->first();

        if($lastOrder){
            return $this->handleResponse(
                true,
                "",
                [],
                [
                    "last_order" => $lastOrder->order
                ],
                [
                    "اخر طلب مكتمل عشان تاخد منه رقم الاوردر للتقييم"
                ]
            );
        }
        return $this->handleResponse(
            false,
            __("order.last not completed"),
            [],
            [],
            []
        );
    }

    public function rate(Request $request){
        $validator = Validator::make($request->all(), [
            "rate" => "required|in:1,2,3,4,5",
            "order_id" => "required|exists:orders,id"
        ]);

        if($validator->fails()){
            return $this->handleResponse(false, "", [$validator->errors()->first()],[],[]);
        }

        $order = Order::where('id', $request->order_id)->where('status', 'completed')->first();

        if($order){
            $order->rate_delivery = $request->rate;
            $order->save();
            $driver = Customer::findOrFail($order->delivery_id);
            $averageRating = Order::where('delivery_id', $driver->id)
                 ->whereNotNull('rate_delivery') // Only include orders that have been rated
                 ->avg('rate_delivery');
         
                // Update the driver's rate column with the average rating
                $driver->delivery_rate = $averageRating ?? 0; // Set 0 if no ratings exist
                $driver->save();
            
            return $this->handleResponse(
                true,
                __("order.rate sent"),
                [],
                [
                    "order" => $order
                ],
                []
            );
        }
        return $this->handleResponse(
            false,
            __("order.can't rate this order"),
            [],
            [],
            ["العميل ميقدرش يقيم الطلبات غير المكتملة (ميقدرش يقيم طلب ملغي او قيد التنفيذ)"]
        );
    }
}
