<?php

namespace App\Filament\Resources\PopularPlaceSuggestionResource\Pages;

use App\Filament\Resources\PopularPlaceSuggestionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePopularPlaceSuggestion extends CreateRecord
{
    protected static string $resource = PopularPlaceSuggestionResource::class;
}
