<?php

namespace App\Filament\Resources\WalletRechargeResource\Pages;

use App\Filament\Resources\WalletRechargeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWalletRecharge extends CreateRecord
{
    protected static string $resource = WalletRechargeResource::class;
}
