<?php

namespace App\Filament\Resources\WalletWithdrawalResource\Pages;

use App\Filament\Resources\WalletWithdrawalResource;
use Filament\Resources\Pages\ViewRecord;

class ViewWalletWithdrawal extends ViewRecord
{
    protected static string $resource = WalletWithdrawalResource::class;
}
